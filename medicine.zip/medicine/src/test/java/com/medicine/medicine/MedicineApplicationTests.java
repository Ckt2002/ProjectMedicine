package com.medicine.medicine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicineApplicationTests {

	@Test
	void contextLoads() {
	}

}
